export interface FavoriteResponseI {
  dataFavorite: {
    id: number,
    user_id: string,
    song_id: string,
    plataform: string
  }
}