export interface FavoriteI {
  song_id: String,
  user_id: String,
  platform: String
}