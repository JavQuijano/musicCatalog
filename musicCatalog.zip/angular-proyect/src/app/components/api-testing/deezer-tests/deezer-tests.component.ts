import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dezzer-tests',
  templateUrl: './deezer-tests.component.html',
  styleUrls: ['./deezer-tests.component.css']
})
export class DeezerTestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
