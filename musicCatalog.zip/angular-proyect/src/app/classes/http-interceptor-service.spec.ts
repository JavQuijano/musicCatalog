import { HttpInterceptorService } from './http-interceptor-service';

describe('HttpInterceptorService', () => {
  it('should create an instance', () => {
    expect(new HttpInterceptorService()).toBeTruthy();
  });
});
