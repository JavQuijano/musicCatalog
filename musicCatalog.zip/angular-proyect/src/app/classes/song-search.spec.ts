import { SongSearch } from './song-search';

describe('SongSearch', () => {
  it('should create an instance', () => {
    expect(new SongSearch()).toBeTruthy();
  });
});
