export interface Album {

}
