import { AlbumSearch } from './album-search';

describe('AlbumSearch', () => {
  it('should create an instance', () => {
    expect(new AlbumSearch()).toBeTruthy();
  });
});
