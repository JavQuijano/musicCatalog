import { Album } from "./album";

export interface AlbumSearch {
}
