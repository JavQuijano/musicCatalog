import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserI } from '../models/user';
import { JwtResponseI } from '../models/jwt-response';
import { tap } from 'rxjs/operators';
import { Observable, BehaviorSubject } from 'rxjs';


@Injectable()
export class AuthService {
  AUTH_SERVER: string = 'http://localhost:3000';
  authSubject = new BehaviorSubject(false);
  private token: string;
  constructor(private httpClient: HttpClient) { }
  /**
   * @param  {UserI} user
   * @returns Observable
   */
  register(user: UserI): Observable<JwtResponseI> {
    return this.httpClient.post<JwtResponseI>(`${this.AUTH_SERVER}/register`,
      user).pipe(tap(
        (res: JwtResponseI) => {
          if (res) {
            this.saveToken(res.dataUser);
          }
        })
      );
  }
  /**
   * @param  {UserI} user
   * @returns Observable
   */
  login(user: UserI): Observable<JwtResponseI> {
    return this.httpClient.post<JwtResponseI>(`${this.AUTH_SERVER}/login`,
      user).pipe(tap(
        (res: JwtResponseI) => {
          if (res) {
            this.saveToken(res.dataUser);
          }
        })
      );
  }
  /**
   * @returns void
   */
  logout(): void {
    this.token = '';
    localStorage.removeItem("ACCESS_TOKEN");
    localStorage.removeItem("EXPIRES_IN");
    localStorage.removeItem("NAME");
    localStorage.removeItem("EMAIL");
  }
  /**
   * @param  {any} user
   * @returns void
   */
  private saveToken(user: any): void {
    localStorage.setItem("ID", user.id);
    localStorage.setItem("ACCESS_TOKEN", user.accessToken);
    localStorage.setItem("EXPIRES_IN", user.expiresIn);
    localStorage.setItem("NAME", user.name);
    localStorage.setItem("EMAIL", user.email);
    this.token = user.accessToken;
  }
  /**
   * @returns string
   */
  private getToken(): string {
    if (!this.token) {
      this.token = localStorage.getItem("ACCESS_TOKEN");
    }
    return this.token;
  }

}
